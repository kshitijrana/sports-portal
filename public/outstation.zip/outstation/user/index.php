<html>
<head>
<link rel="stylesheet" type="text/css" href="../stylesheets/style.css">
	<title>Outstation Registration</title>
</head>
<body>
<h1 id="heading_1">Outstation Registrations.</h1>
	<div align = "center" id="iframe"><iframe src="form.php" style="border:none;width:50%;height:100%;align:center;"></iframe></div>
</body>
</html>